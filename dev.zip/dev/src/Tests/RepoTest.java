package Tests;

import DataAccessLayer.Repo;
import org.junit.internal.TextListener;
import org.junit.runner.JUnitCore;

public class RepoTest {

    public static void main(String[] args)
    {
        Repo.createDatabase();
    }
}
