package Tests;

import org.junit.internal.TextListener;
import org.junit.runner.JUnitCore;


public class tests {

    public static void main(String[] args)
    {
        System.out.println("3".compareTo("1"));
    }
}
