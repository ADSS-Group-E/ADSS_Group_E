package BussinessLayer.WorkersPackage;

public enum ShiftType {
    Morning,
    Evening
}
