package PresentationLayer;

public enum QualificationsDTO {
    Cashier,
    Storekeeper,
    Arranger,
    Human_Resources_Director,
    Guard,
    BranchManager,
    Assistant,
    ShiftManager;
}
