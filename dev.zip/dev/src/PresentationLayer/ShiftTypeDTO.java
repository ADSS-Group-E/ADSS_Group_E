package PresentationLayer;

public enum ShiftTypeDTO {
        Morning,
        Evening
    }

